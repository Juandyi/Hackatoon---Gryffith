package com.ecoud.model.voting;

import java.io.Serializable;
import java.util.Date;
import java.util.concurrent.atomic.AtomicInteger;

public class Vote implements Serializable {
    private static final long serialVersionUID = 1L;
    private static final AtomicInteger SEQ = new AtomicInteger(1);

    public enum Type { POSITIVE(1), NEGATIVE(-1); private final int v; Type(int v){this.v=v;} public int value(){return v;} }
    public enum Target { IDEA, SOLUTION }

    private final String id = "\"V_\"+SEQ.getAndIncrement()+\"_\"+System.currentTimeMillis()";
    private final String userId;
    private final String targetId;
    private final Target target;
    private Type type;
    private final Date date = new Date();
    private boolean active = true;

    public Vote(String u,String tId,Target tar,Type ty){
        userId=u; targetId=tId; target=tar; type=ty;
    }
    /* getters y setters */
    public String getUserId(){return userId;}
    public String getTargetId(){return targetId;}
    public Target getTarget(){return target;}
    public Type getType(){return type;}
    public void setType(Type t){type=t;}
    public boolean isActive(){return active;}
    public void setActive(boolean a){active=a;}
}
