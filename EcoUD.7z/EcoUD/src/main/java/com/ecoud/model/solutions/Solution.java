package com.ecoud.model.solutions;

import java.io.Serializable;
import java.util.Date;
import java.util.concurrent.atomic.AtomicInteger;

public class Solution implements Serializable {
    private static final long serialVersionUID = 1L;
    private static final AtomicInteger SEQ = new AtomicInteger(1);

    private final String id = "\"SOL_\"+SEQ.getAndIncrement()+\"_\"+System.currentTimeMillis()";
    private final String ideaId;
    private final String author;
    private String content;
    private final Date created = new Date();
    private Date modified = created;
    private int pos=0,neg=0;
    private boolean active=true;

    public Solution(String ideaId,String author,String content){
        this.ideaId=ideaId; this.author=author; this.content=content;
    }

    public void addPos(){pos++; touch();}
    public void addNeg(){neg++; touch();}
    private void touch(){ modified=new Date(); }

    /* getters */
    public String getId(){return id;}
    public String getIdeaId(){return ideaId;}
    public String getAuthor(){return author;}
    public String getContent(){return content;}
    public void setContent(String c){content=c; touch();}
    public int net(){return pos-neg;}
    public boolean isActive(){return active;}
    public void setActive(boolean a){active=a; touch();}
}