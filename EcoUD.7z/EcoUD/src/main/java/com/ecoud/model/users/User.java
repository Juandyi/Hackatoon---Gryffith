package com.ecoud.model.users;

import java.io.Serializable;
import java.util.Date;

public abstract class User implements Serializable {
    private static final long serialVersionUID = 1L;

    protected String username;
    protected String password;
    protected int points;
    protected Date registrationDate;
    protected boolean active;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
        this.points = 0;
        this.registrationDate = new Date();
        this.active = true;
    }

    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public int getPoints() { return points; }
    public Date getRegistrationDate() { return registrationDate; }
    public boolean isActive() { return active; }

    public void setPassword(String password) { this.password = password; }
    public void addPoints(int pts) { this.points += pts; }
    public void setActive(boolean active) { this.active = active; }

    public abstract String getUserType();

    @Override
    public int hashCode() { return username.hashCode(); }

    @Override
    public boolean equals(Object o) {
        return (o instanceof User u) && username.equals(u.username);
    }
}
