package com.ecoud.model.voting;

public record VoteStatistics(int positives,int negatives,int net,double approval) {}
