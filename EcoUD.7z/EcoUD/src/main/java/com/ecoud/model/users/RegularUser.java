package com.ecoud.model.users;

import java.util.ArrayList;
import java.util.List;

public class RegularUser extends User {
    private static final long serialVersionUID = 1L;

    private final List<String> ideaIds = new ArrayList<>();
    private final List<String> voteIds = new ArrayList<>();
    private final List<String> solutionIds = new ArrayList<>();

    public RegularUser(String username, String password) {
        super(username, password);
    }

    @Override
    public String getUserType() { return "REGULAR"; }

    public void addIdea(String id) { ideaIds.add(id); addPoints(10); }
    public void addVote(String id) { 
        if (!voteIds.contains(id)) { voteIds.add(id); addPoints(1); }
    }
    public void addSolution(String id) { solutionIds.add(id); addPoints(15); }

    public boolean hasVoted(String id) { return voteIds.contains(id); }
}
