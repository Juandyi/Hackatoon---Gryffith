package com.ecoud.model.voting;

public record VoteResult(boolean success,String message,Vote.Type newType) {}
