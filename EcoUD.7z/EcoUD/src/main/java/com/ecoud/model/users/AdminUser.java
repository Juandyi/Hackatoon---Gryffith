package com.ecoud.model.users;

import java.util.ArrayList;
import java.util.List;

public class AdminUser extends User {
    private static final long serialVersionUID = 1L;

    private final List<String> moderationLog = new ArrayList<>();

    public AdminUser(String username, String password) {
        super(username, password);
    }

    @Override
    public String getUserType() { return "ADMIN"; }

    public void log(String action) { moderationLog.add(action); }
    public List<String> getModerationLog() { return List.copyOf(moderationLog); }
}
